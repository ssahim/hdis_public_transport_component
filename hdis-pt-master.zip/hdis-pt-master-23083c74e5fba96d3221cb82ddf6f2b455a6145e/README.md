# HDIS NiteOut Semester Project - Public Transport Component

## Releases

* **[v0.2](https://tubcloud.tu-berlin.de/index.php/s/keQMZ2NlZgoFA4i)**
* [v0.1](https://tubcloud.tu-berlin.de/index.php/s/hL4ldj5D9rvADqp)

## Members

Name | Directions Subgroup | Email| Mobile
--- | --- | --- | ---
Sayed Ahmad Sahim  | Public Transport | <sahim@campus.tu-berlin.de> | 0152 14874335
Thomas Wirth (speaker) | Public Transport | <t.wirth@campus.tu-berlin.de> | 01573 1910987
Amin Gul Zakhil (deputy) | Walking | <a.zakhil@compus.tu-berlin.de> | 0152 11528840
Andres Ardila (lead) | Walking | <a.ardila@campus.tu-berlin.de> | 0176 58628598
Vamsee Mithra Kilari | – | <kilari@campus.tu-berlin.de> | 0174 5945603


### Data Integration Contact Persons

* Thomas (Public Transport directions)
* Andres (Walking directions)

## Group Communication

https://hdis-pt.slack.com/

## Document storage

Google Drive
Folder owner: Andres
