package de.tu_berlin.dima.niteout.routing.model;

public enum DistanceUnits {
	KILOMETERS,
	MILES
}
