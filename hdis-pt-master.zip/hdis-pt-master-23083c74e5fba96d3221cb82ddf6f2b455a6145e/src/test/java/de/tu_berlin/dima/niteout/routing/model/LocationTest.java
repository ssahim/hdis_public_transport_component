package de.tu_berlin.dima.niteout.routing.model;

import org.junit.Test;

/**
 * Test class for {@link Location}.
 */
public class LocationTest {

    @Test
    public void test() {
        //TODO add tests
    }
}
